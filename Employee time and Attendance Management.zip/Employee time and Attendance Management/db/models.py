from db.database import connect_db


# Add a new employee
def add_employee(name, position, hourly_rate):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO employees (name, position, hourly_rate)
        VALUES (?, ?, ?)
    """, (name, position, hourly_rate))
    conn.commit()
    conn.close()

# Log attendance
def log_attendance(employee_id, clock_in, clock_out=None):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO attendance (employee_id, clock_in, clock_out)
        VALUES (?, ?, ?)
    """, (employee_id, clock_in, clock_out))
    conn.commit()
    conn.close()

# Update clock-out time
def update_clock_out(attendance_id, clock_out):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE attendance
        SET clock_out = ?
        WHERE id = ?
    """, (clock_out, attendance_id))
    conn.commit()
    conn.close()

# Generate payroll
def generate_payroll():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO payroll (employee_id, total_hours, overtime_hours, total_pay)
        SELECT 
            employee_id,
            SUM(total_hours),
            SUM(overtime_hours),
            SUM(total_hours * hourly_rate + overtime_hours * hourly_rate * 1.5)
        FROM attendance
        JOIN employees ON attendance.employee_id = employees.id
        GROUP BY employee_id
    """)
    conn.commit()
    conn.close()
