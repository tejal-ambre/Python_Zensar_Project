import sqlite3

# Database connection
def connect_db():
    return sqlite3.connect("employee_attendance.db")

# Initialize the database
def initialize_db():
    conn = connect_db()
    cursor = conn.cursor()

    # Create employees table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            position TEXT,
            hourly_rate REAL NOT NULL
        )
    """)

    # Create attendance table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            clock_in DATETIME,
            clock_out DATETIME,
            total_hours REAL DEFAULT 0,
            overtime_hours REAL DEFAULT 0,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
    """)

    # Create payroll table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS payroll (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            total_hours REAL,
            overtime_hours REAL,
            total_pay REAL,
            generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
    """)

    # Trigger to calculate total and overtime hours
    cursor.execute("""
        CREATE TRIGGER IF NOT EXISTS calculate_hours
        AFTER UPDATE ON attendance
        FOR EACH ROW
        WHEN NEW.clock_out IS NOT NULL
        BEGIN
            UPDATE attendance
            SET total_hours = 
                (strftime('%s', NEW.clock_out) - strftime('%s', NEW.clock_in)) / 3600,
                overtime_hours = CASE 
                    WHEN total_hours > 8 THEN total_hours - 8
                    ELSE 0
                END
            WHERE id = NEW.id;
        END;
    """)

    conn.commit()
    conn.close()
