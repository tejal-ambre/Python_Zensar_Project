from db.models import add_employee, log_attendance, update_clock_out, generate_payroll
from attendance_report import generate_attendance_report, generate_payroll_report
from datetime import datetime

def main():
    print("Employee Time and Attendance Management System")
    print("1. Add Employee")
    print("2. Log Attendance")
    print("3. Update Clock-out Time")
    print("4. Generate Payroll")
    print("5. Generate Reports")
    choice = int(input("Enter your choice: "))

    if choice == 1:
        name = input("Enter employee name: ")
        position = input("Enter position: ")
        hourly_rate = float(input("Enter hourly rate: "))
        add_employee(name, position, hourly_rate)
        print("Employee added successfully.")
    
    elif choice == 2:
        employee_id = int(input("Enter employee ID: "))
        clock_in = input("Enter clock-in time (YYYY-MM-DD HH:MM:SS): ")
        log_attendance(employee_id, clock_in)
        print("Attendance logged successfully.")
    
    elif choice == 3:
        attendance_id = int(input("Enter attendance ID: "))
        clock_out = input("Enter clock-out time (YYYY-MM-DD HH:MM:SS): ")
        update_clock_out(attendance_id, clock_out)
        print("Clock-out time updated successfully.")
    
    elif choice == 4:
        generate_payroll()
        print("Payroll generated successfully.")
    
    elif choice == 5:
        generate_attendance_report()
        generate_payroll_report()
    
    else:
        print("Invalid choice.")

if __name__ == "__main__":
    main()
