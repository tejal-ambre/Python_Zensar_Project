import pandas as pd
from db.database import connect_db

# Generate attendance report
def generate_attendance_report():
    conn = connect_db()
    df = pd.read_sql_query("SELECT * FROM attendance", conn)
    df.to_csv("attendance_report.csv", index=False)
    conn.close()
    print("Attendance report saved as attendance_report.csv")

# Generate payroll report
def generate_payroll_report():
    conn = connect_db()
    df = pd.read_sql_query("SELECT * FROM payroll", conn)
    df.to_csv("payroll_report.csv", index=False)
    conn.close()
    print("Payroll report saved as payroll_report.csv")
