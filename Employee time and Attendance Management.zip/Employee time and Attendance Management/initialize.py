from db.database import initialize_db

# Initialize the database and create tables
initialize_db()
print("Database initialized successfully.")
